function main(infile)
% ======================================================================================== %
%                           Levelized Cost of Energy Calculator                            %
% ======================================================================================== %
% Author: Gregory T. Forcherio                                                             %
%                                                                                          %
% ---------------------------------------------------------------------------------------- %
%         this script calculates the Levelized Cost of Energy for a typical energy         %
%            supply system based off of operating costs and capital financing              %
%                                                                                          %
%     Inputs: period  = Period (years)                  OMcost = Maitenance Cost ($/kWyr)  %
%             disc    = Discount Rate (%)               heat   = Heating Rate (Btu/kWh)    %
%             ccost   = Capital Cost ($/kWh)            fuel   = Fuel Cost ($/MMBtu)       %
%             cfactor = Capacity Factor (%)                                                %
%                                                                                          % 
%               Outputs: CRF  = Capital Recovery Factor                                    %
%                        LCOE = Levelized Cost of Energy (cents/kWh)                       %
%                                                                                          %
%----------------------------------------------------------------------------------------- %

io = rpLib(infile);	% open XML file containing current run parameters

% gather input parameters from Rappture
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
period = rpLibGetDouble(io,'input.group(tabs).group(financial).integer(period).current');  %Period
disc = rpLibGetDouble(io,'input.group(tabs).group(financial).number(disc).current');       %Discount Rate
ccost = rpLibGetDouble(io,'input.group(tabs).group(perf).integer(ccost).current');         %Capital Cost
cfactor = rpLibGetDouble(io,'input.group(tabs).group(perf).number(cfactor).current');      %Capacity Factor
OMcost = rpLibGetDouble(io,'input.group(tabs).group(perf).integer(OMcost).current');       %O&M Cost
			% obtain user specified Boolean for energy type
str = rpLibGetString(io,'input.group(tabs).group(perf).boolean(source).current');
source = strcmpi(str,'yes');

if source == 1
    heat = 0;	        %make both 0 because renewable 
    fuel = 0;           %sources have no fuel costs 
else
    heat = rpLibGetDouble(io,'input.group(tabs).group(perf).integer(heat).current');      %Heat Rate
    fuel = rpLibGetDouble(io,'input.group(tabs).group(perf).number(fuel).current');       %Fuel Cost
end

% use the inputs to calculated CRF and LCOE outputs
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
CRF = (disc*(disc+1)^period)/((disc+1)^period-1);
LCOE = ((ccost*CRF+OMcost)/(8760*cfactor)+(fuel*heat/1000000))*100;

% send output values back to Rappture
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
					
rpLibPutString(io,'output.number(CRF).current',num2str(CRF),0);	       % plot CRF value			 
rpLibPutString(io,'output.number(LCOE).current',num2str(LCOE),0);      % plot LCOE value


rpLibResult(io);
quit;
